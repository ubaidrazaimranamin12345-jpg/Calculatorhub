import ScientificCalculatorComponent from "@/components/calculators/scientific-calculator";
import CalculatorGrid from "@/components/calculator-grid";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Hero Section with Scientific Calculator */}
        <div className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Free Online Calculators</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Access 200+ professional calculators for math, finance, health, and more. 
              All completely free with no registration required.
            </p>
          </div>

          <ScientificCalculatorComponent />
        </div>

        {/* Calculator Categories */}
        <CalculatorGrid />
      </div>
    </div>
  );
}
