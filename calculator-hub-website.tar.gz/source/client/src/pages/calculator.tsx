import { useParams } from "wouter";
import { ArrowLeft, Home } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { calculators } from "@/lib/calculator-data";

// Import calculator components
import ScientificCalculatorComponent from "@/components/calculators/scientific-calculator";
import MortgageCalculator from "@/components/calculators/mortgage-calculator";
import BMICalculator from "@/components/calculators/bmi-calculator";
import LoanCalculator from "@/components/calculators/loan-calculator";
import PercentageCalculator from "@/components/calculators/percentage-calculator";
import AgeCalculator from "@/components/calculators/age-calculator";

export default function Calculator() {
  const params = useParams();
  const calculatorId = params.id;
  
  const calculator = calculators.find(calc => calc.id === calculatorId);
  
  if (!calculator) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-slate-900 mb-4">Calculator Not Found</h1>
          <p className="text-slate-600 mb-6">The requested calculator could not be found.</p>
          <Link href="/">
            <Button>
              <Home className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const renderCalculator = () => {
    switch (calculatorId) {
      case "scientific":
        return <ScientificCalculatorComponent />;
      case "mortgage":
        return <MortgageCalculator />;
      case "bmi":
        return <BMICalculator />;
      case "loan":
        return <LoanCalculator />;
      case "percentage":
        return <PercentageCalculator />;
      case "age":
        return <AgeCalculator />;
      default:
        return (
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <h3 className="text-xl font-semibold text-slate-900 mb-4">
              {calculator.name}
            </h3>
            <p className="text-slate-600 mb-6">
              This calculator is coming soon! We're working on implementing all our calculators.
            </p>
            <p className="text-sm text-slate-500">
              {calculator.description}
            </p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Calculators
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">{calculator.name}</h1>
              <p className="text-slate-600">{calculator.description}</p>
            </div>
          </div>
        </div>

        {/* Calculator Component */}
        {renderCalculator()}

        {/* Related Calculators */}
        <div className="mt-12">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Related Calculators</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {calculators
              .filter(calc => calc.category === calculator.category && calc.id !== calculatorId)
              .slice(0, 3)
              .map(relatedCalc => (
                <Link key={relatedCalc.id} href={`/calculator/${relatedCalc.id}`}>
                  <div className="bg-white rounded-lg border border-slate-200 p-4 hover:shadow-md hover:border-blue-200 transition-all cursor-pointer">
                    <h4 className="font-medium text-slate-900 mb-2">{relatedCalc.name}</h4>
                    <p className="text-sm text-slate-600">{relatedCalc.description}</p>
                  </div>
                </Link>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
