import { Calculator, Home, Heart, Brain, Settings } from "lucide-react";

export interface CalculatorInfo {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  color: string;
}

export const calculatorCategories = [
  {
    id: "financial",
    name: "Financial Calculators",
    description: "Mortgage, loan, investment, and tax calculators",
    icon: "dollar-sign",
    color: "green"
  },
  {
    id: "health",
    name: "Health & Fitness Calculators", 
    description: "BMI, calorie, fitness, and health tracking tools",
    icon: "heartbeat",
    color: "red"
  },
  {
    id: "math",
    name: "Math Calculators",
    description: "Scientific, algebraic, and statistical calculations",
    icon: "calculator",
    color: "blue"
  },
  {
    id: "other",
    name: "Other Calculators",
    description: "Utility, conversion, and specialized calculation tools",
    icon: "cogs",
    color: "gray"
  }
];

export const calculators: CalculatorInfo[] = [
  // Financial Calculators
  {
    id: "mortgage",
    name: "Mortgage Calculator",
    description: "Calculate monthly payments, interest, and amortization schedules",
    category: "financial",
    icon: "home",
    color: "green"
  },
  {
    id: "auto-loan",
    name: "Auto Loan Calculator", 
    description: "Determine car loan payments and total interest costs",
    category: "financial",
    icon: "car",
    color: "blue"
  },
  {
    id: "investment",
    name: "Investment Calculator",
    description: "Calculate compound returns on your investments",
    category: "financial",
    icon: "trending-up",
    color: "purple"
  },
  {
    id: "tax",
    name: "Tax Calculator",
    description: "Estimate income tax and take-home pay",
    category: "financial",
    icon: "receipt",
    color: "red"
  },
  {
    id: "retirement",
    name: "Retirement Calculator",
    description: "Plan your retirement savings and 401k contributions",
    category: "financial",
    icon: "piggy-bank",
    color: "indigo"
  },
  {
    id: "interest",
    name: "Interest Calculator",
    description: "Calculate simple and compound interest on savings",
    category: "financial",
    icon: "percent",
    color: "yellow"
  },
  {
    id: "loan",
    name: "Loan Calculator",
    description: "Calculate personal and business loan payments",
    category: "financial",
    icon: "hand-coins",
    color: "teal"
  },
  {
    id: "salary",
    name: "Salary Calculator",
    description: "Convert between hourly, weekly, monthly, and yearly pay",
    category: "financial",
    icon: "coins",
    color: "orange"
  },

  // Health & Fitness Calculators
  {
    id: "bmi",
    name: "BMI Calculator",
    description: "Calculate Body Mass Index and health status",
    category: "health",
    icon: "weight",
    color: "pink"
  },
  {
    id: "calorie",
    name: "Calorie Calculator",
    description: "Calculate daily calorie needs and burned calories",
    category: "health",
    icon: "flame",
    color: "orange"
  },
  {
    id: "body-fat",
    name: "Body Fat Calculator",
    description: "Estimate body fat percentage using measurements",
    category: "health",
    icon: "user",
    color: "blue"
  },
  {
    id: "bmr",
    name: "BMR Calculator",
    description: "Calculate Basal Metabolic Rate and daily energy needs",
    category: "health",
    icon: "activity",
    color: "green"
  },
  {
    id: "ideal-weight",
    name: "Ideal Weight Calculator",
    description: "Find your ideal weight range based on height",
    category: "health",
    icon: "target",
    color: "purple"
  },
  {
    id: "pace",
    name: "Pace Calculator",
    description: "Calculate running pace and race times",
    category: "health",
    icon: "timer",
    color: "indigo"
  },
  {
    id: "pregnancy",
    name: "Pregnancy Calculator",
    description: "Calculate due date and pregnancy milestones",
    category: "health",
    icon: "baby",
    color: "rose"
  },
  {
    id: "macro",
    name: "Macro Calculator",
    description: "Calculate optimal protein, carbs, and fat intake",
    category: "health",
    icon: "utensils",
    color: "cyan"
  },

  // Math Calculators
  {
    id: "scientific",
    name: "Scientific Calculator",
    description: "Advanced mathematical operations and functions",
    category: "math",
    icon: "calculator",
    color: "blue"
  },
  {
    id: "fraction",
    name: "Fraction Calculator",
    description: "Add, subtract, multiply, and divide fractions",
    category: "math",
    icon: "divide",
    color: "green"
  },
  {
    id: "percentage",
    name: "Percentage Calculator",
    description: "Calculate percentages, increases, and decreases",
    category: "math",
    icon: "percent",
    color: "purple"
  },
  {
    id: "standard-deviation",
    name: "Standard Deviation Calculator",
    description: "Calculate statistical variance and standard deviation",
    category: "math",
    icon: "bar-chart",
    color: "red"
  },
  {
    id: "triangle",
    name: "Triangle Calculator",
    description: "Calculate area, perimeter, and triangle properties",
    category: "math",
    icon: "triangle",
    color: "yellow"
  },
  {
    id: "random-number",
    name: "Random Number Generator",
    description: "Generate random numbers within specified ranges",
    category: "math",
    icon: "shuffle",
    color: "indigo"
  },
  {
    id: "volume",
    name: "Volume Calculator",
    description: "Calculate volume of geometric shapes and objects",
    category: "math",
    icon: "cube",
    color: "teal"
  },
  {
    id: "area",
    name: "Area Calculator",
    description: "Calculate area of squares, circles, triangles, and more",
    category: "math",
    icon: "square",
    color: "orange"
  },

  // Other Calculators
  {
    id: "age",
    name: "Age Calculator",
    description: "Calculate age in years, months, days, and more",
    category: "other",
    icon: "cake",
    color: "slate"
  },
  {
    id: "date",
    name: "Date Calculator",
    description: "Add/subtract days, months, years to dates",
    category: "other",
    icon: "calendar",
    color: "blue"
  },
  {
    id: "time",
    name: "Time Calculator",
    description: "Add, subtract, and convert time units",
    category: "other",
    icon: "clock",
    color: "green"
  },
  {
    id: "gpa",
    name: "GPA Calculator",
    description: "Calculate grade point average and academic performance",
    category: "other",
    icon: "graduation-cap",
    color: "purple"
  },
  {
    id: "unit-converter",
    name: "Unit Converter",
    description: "Convert between temperature, length, weight, and volume",
    category: "other",
    icon: "thermometer",
    color: "red"
  },
  {
    id: "password-generator",
    name: "Password Generator",
    description: "Generate secure passwords with custom criteria",
    category: "other",
    icon: "key",
    color: "yellow"
  },
  {
    id: "ip-subnet",
    name: "IP Subnet Calculator",
    description: "Calculate network subnets and IP address ranges",
    category: "other",
    icon: "network",
    color: "indigo"
  },
  {
    id: "construction",
    name: "Construction Calculator",
    description: "Calculate concrete, materials, and project measurements",
    category: "other",
    icon: "hard-hat",
    color: "orange"
  }
];
