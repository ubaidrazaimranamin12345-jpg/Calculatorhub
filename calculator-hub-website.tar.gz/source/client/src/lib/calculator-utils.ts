// Mathematical calculation utilities

export class ScientificCalculator {
  static evaluate(expression: string): number {
    try {
      // Replace mathematical functions with JavaScript equivalents
      let expr = expression
        .replace(/sin\(/g, 'Math.sin(')
        .replace(/cos\(/g, 'Math.cos(')
        .replace(/tan\(/g, 'Math.tan(')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/sqrt\(/g, 'Math.sqrt(')
        .replace(/\^/g, '**')
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E');

      // Use Function constructor for safer evaluation
      return new Function('return ' + expr)();
    } catch (error) {
      throw new Error('Invalid expression');
    }
  }

  static toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  static toDegrees(radians: number): number {
    return radians * (180 / Math.PI);
  }
}

export class FinancialCalculator {
  static calculateMortgage(
    principal: number,
    annualRate: number,
    years: number
  ): { monthlyPayment: number; totalInterest: number; totalPayment: number } {
    const monthlyRate = annualRate / 100 / 12;
    const numPayments = years * 12;
    
    const monthlyPayment = principal * 
      (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) /
      (Math.pow(1 + monthlyRate, numPayments) - 1);
    
    const totalPayment = monthlyPayment * numPayments;
    const totalInterest = totalPayment - principal;
    
    return {
      monthlyPayment: Math.round(monthlyPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      totalPayment: Math.round(totalPayment * 100) / 100
    };
  }

  static calculateLoan(
    principal: number,
    annualRate: number,
    months: number
  ): { monthlyPayment: number; totalInterest: number; totalPayment: number } {
    const monthlyRate = annualRate / 100 / 12;
    
    const monthlyPayment = principal * 
      (monthlyRate * Math.pow(1 + monthlyRate, months)) /
      (Math.pow(1 + monthlyRate, months) - 1);
    
    const totalPayment = monthlyPayment * months;
    const totalInterest = totalPayment - principal;
    
    return {
      monthlyPayment: Math.round(monthlyPayment * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100,
      totalPayment: Math.round(totalPayment * 100) / 100
    };
  }

  static calculateCompoundInterest(
    principal: number,
    annualRate: number,
    years: number,
    compoundFrequency: number = 12
  ): { finalAmount: number; totalInterest: number } {
    const finalAmount = principal * Math.pow(
      1 + (annualRate / 100) / compoundFrequency,
      compoundFrequency * years
    );
    
    const totalInterest = finalAmount - principal;
    
    return {
      finalAmount: Math.round(finalAmount * 100) / 100,
      totalInterest: Math.round(totalInterest * 100) / 100
    };
  }
}

export class HealthCalculator {
  static calculateBMI(weight: number, height: number, unit: 'metric' | 'imperial' = 'metric'): {
    bmi: number;
    category: string;
    healthyRange: { min: number; max: number };
  } {
    let heightInMeters = height;
    let weightInKg = weight;
    
    if (unit === 'imperial') {
      heightInMeters = height * 0.0254; // inches to meters
      weightInKg = weight * 0.453592; // pounds to kg
    } else {
      heightInMeters = height / 100; // cm to meters
    }
    
    const bmi = weightInKg / (heightInMeters * heightInMeters);
    
    let category = '';
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi < 25) category = 'Normal weight';
    else if (bmi < 30) category = 'Overweight';
    else category = 'Obese';
    
    const healthyRange = {
      min: Math.round(18.5 * heightInMeters * heightInMeters * 100) / 100,
      max: Math.round(24.9 * heightInMeters * heightInMeters * 100) / 100
    };
    
    return {
      bmi: Math.round(bmi * 10) / 10,
      category,
      healthyRange
    };
  }

  static calculateBMR(
    weight: number,
    height: number,
    age: number,
    gender: 'male' | 'female',
    unit: 'metric' | 'imperial' = 'metric'
  ): number {
    let weightInKg = weight;
    let heightInCm = height;
    
    if (unit === 'imperial') {
      weightInKg = weight * 0.453592; // pounds to kg
      heightInCm = height * 2.54; // inches to cm
    }
    
    // Mifflin-St Jeor Equation
    let bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * age;
    bmr += gender === 'male' ? 5 : -161;
    
    return Math.round(bmr);
  }

  static calculateCalorieNeeds(bmr: number, activityLevel: string): number {
    const multipliers: { [key: string]: number } = {
      'sedentary': 1.2,
      'lightly-active': 1.375,
      'moderately-active': 1.55,
      'very-active': 1.725,
      'extra-active': 1.9
    };
    
    return Math.round(bmr * (multipliers[activityLevel] || 1.2));
  }
}

export class MathCalculator {
  static calculatePercentage(value: number, percentage: number): number {
    return (value * percentage) / 100;
  }

  static calculatePercentageChange(oldValue: number, newValue: number): number {
    return ((newValue - oldValue) / oldValue) * 100;
  }

  static calculateStandardDeviation(values: number[]): {
    mean: number;
    variance: number;
    standardDeviation: number;
  } {
    const mean = values.reduce((sum, val) => sum + val, 0) / values.length;
    const variance = values.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / values.length;
    const standardDeviation = Math.sqrt(variance);
    
    return {
      mean: Math.round(mean * 100) / 100,
      variance: Math.round(variance * 100) / 100,
      standardDeviation: Math.round(standardDeviation * 100) / 100
    };
  }

  static calculateTriangleArea(base: number, height: number): number {
    return (base * height) / 2;
  }

  static calculateTrianglePerimeter(side1: number, side2: number, side3: number): number {
    return side1 + side2 + side3;
  }

  static generateRandomNumber(min: number, max: number, decimals: number = 0): number {
    const random = Math.random() * (max - min) + min;
    return Math.round(random * Math.pow(10, decimals)) / Math.pow(10, decimals);
  }
}

export class UtilityCalculator {
  static calculateAge(birthDate: Date): {
    years: number;
    months: number;
    days: number;
    totalDays: number;
  } {
    const today = new Date();
    const birth = new Date(birthDate);
    
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    let days = today.getDate() - birth.getDate();
    
    if (days < 0) {
      months--;
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      days += lastMonth.getDate();
    }
    
    if (months < 0) {
      years--;
      months += 12;
    }
    
    const totalDays = Math.floor((today.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));
    
    return { years, months, days, totalDays };
  }

  static addDaysToDate(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  static calculateDateDifference(date1: Date, date2: Date): number {
    const diffTime = Math.abs(date2.getTime() - date1.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }

  static generateSecurePassword(
    length: number,
    includeUppercase: boolean = true,
    includeLowercase: boolean = true,
    includeNumbers: boolean = true,
    includeSymbols: boolean = true
  ): string {
    let chars = '';
    if (includeUppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeLowercase) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    let password = '';
    for (let i = 0; i < length; i++) {
      password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return password;
  }
}
