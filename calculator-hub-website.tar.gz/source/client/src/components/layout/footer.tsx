import { Calculator } from "lucide-react";

export default function Footer() {
  const popularTools = [
    { name: "Mortgage Calculator", href: "/calculator/mortgage" },
    { name: "BMI Calculator", href: "/calculator/bmi" },
    { name: "Scientific Calculator", href: "/calculator/scientific" },
    { name: "Percentage Calculator", href: "/calculator/percentage" },
    { name: "Investment Calculator", href: "/calculator/investment" },
  ];

  const categories = [
    { name: "Financial", href: "/#financial" },
    { name: "Health & Fitness", href: "/#health" },
    { name: "Math", href: "/#math" },
    { name: "Other Tools", href: "/#other" },
    { name: "All Calculators", href: "/" },
  ];

  return (
    <footer className="bg-white border-t border-slate-200 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Calculator className="h-6 w-6 text-blue-600" />
              <h3 className="text-lg font-semibold text-slate-900">Calculator Hub</h3>
            </div>
            <p className="text-slate-600 mb-4">
              Free online calculators for math, finance, health, and more. All tools are 
              completely free with no registration required.
            </p>
            <div className="flex items-center space-x-4 text-slate-500">
              <span className="text-sm">© 2024 Calculator Hub</span>
              <span className="text-sm">200+ Calculators</span>
              <span className="text-sm">Always Free</span>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-3">Popular Tools</h4>
            <ul className="space-y-2 text-sm">
              {popularTools.map((tool) => (
                <li key={tool.name}>
                  <a 
                    href={tool.href} 
                    className="text-slate-600 hover:text-blue-600 transition-colors"
                  >
                    {tool.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-3">Categories</h4>
            <ul className="space-y-2 text-sm">
              {categories.map((category) => (
                <li key={category.name}>
                  <a 
                    href={category.href} 
                    className="text-slate-600 hover:text-blue-600 transition-colors"
                  >
                    {category.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
