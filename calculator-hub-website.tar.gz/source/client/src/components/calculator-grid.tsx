import { Link } from "wouter";
import { 
  DollarSign, Heart, Calculator as CalcIcon, Settings,
  Home, Car, TrendingUp, Receipt, PiggyBank, Percent, HandCoins, Coins,
  Weight, Flame, User, Activity, Target, Timer, Baby, Utensils,
  SquareRadical, Divide, BarChart, Triangle, Shuffle, Box, Square,
  Cake, Calendar, Clock, GraduationCap, Thermometer, Key, Network, HardHat
} from "lucide-react";
import { calculatorCategories, calculators } from "@/lib/calculator-data";

const iconMap: { [key: string]: any } = {
  "dollar-sign": DollarSign,
  "heartbeat": Heart,
  "calculator": CalcIcon,
  "cogs": Settings,
  "home": Home,
  "car": Car,
  "trending-up": TrendingUp,
  "receipt": Receipt,
  "piggy-bank": PiggyBank,
  "percent": Percent,
  "hand-coins": HandCoins,
  "coins": Coins,
  "weight": Weight,
  "flame": Flame,
  "user": User,
  "activity": Activity,
  "target": Target,
  "timer": Timer,
  "baby": Baby,
  "utensils": Utensils,
  "square-root": SquareRadical,
  "divide": Divide,
  "bar-chart": BarChart,
  "triangle": Triangle,
  "shuffle": Shuffle,
  "cube": Box,
  "square": Square,
  "cake": Cake,
  "calendar": Calendar,
  "clock": Clock,
  "graduation-cap": GraduationCap,
  "thermometer": Thermometer,
  "key": Key,
  "network": Network,
  "hard-hat": HardHat,
};

const colorMap: { [key: string]: string } = {
  "green": "bg-green-100 group-hover:bg-green-200 text-green-600",
  "blue": "bg-blue-100 group-hover:bg-blue-200 text-blue-600",
  "purple": "bg-purple-100 group-hover:bg-purple-200 text-purple-600",
  "red": "bg-red-100 group-hover:bg-red-200 text-red-600",
  "indigo": "bg-indigo-100 group-hover:bg-indigo-200 text-indigo-600",
  "yellow": "bg-yellow-100 group-hover:bg-yellow-200 text-yellow-600",
  "teal": "bg-teal-100 group-hover:bg-teal-200 text-teal-600",
  "orange": "bg-orange-100 group-hover:bg-orange-200 text-orange-600",
  "pink": "bg-pink-100 group-hover:bg-pink-200 text-pink-600",
  "cyan": "bg-cyan-100 group-hover:bg-cyan-200 text-cyan-600",
  "rose": "bg-rose-100 group-hover:bg-rose-200 text-rose-600",
  "slate": "bg-slate-100 group-hover:bg-slate-200 text-slate-600",
  "gray": "bg-gray-100 group-hover:bg-gray-200 text-gray-600",
};

interface CalculatorGridProps {
  category?: string;
}

export default function CalculatorGrid({ category }: CalculatorGridProps) {
  const filteredCalculators = category 
    ? calculators.filter(calc => calc.category === category)
    : calculators;

  const getIcon = (iconName: string) => {
    const IconComponent = iconMap[iconName] || CalcIcon;
    return IconComponent;
  };

  return (
    <div className="space-y-12">
      {calculatorCategories.map(cat => {
        if (category && cat.id !== category) return null;
        
        const categoryCalculators = calculators.filter(calc => calc.category === cat.id);
        const CategoryIcon = getIcon(cat.icon);
        
        return (
          <section key={cat.id} id={cat.id}>
            <div className="flex items-center space-x-3 mb-6">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colorMap[cat.color]}`}>
                <CategoryIcon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-2xl font-semibold text-slate-900">{cat.name}</h3>
                <p className="text-slate-600">{cat.description}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {categoryCalculators.map(calc => {
                const Icon = getIcon(calc.icon);
                const colorClasses = colorMap[calc.color];
                
                return (
                  <Link 
                    key={calc.id} 
                    href={`/calculator/${calc.id}`}
                    className="group"
                  >
                    <div className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-lg hover:border-blue-200 transition-all cursor-pointer">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-colors ${colorClasses}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <h4 className="font-semibold text-slate-900 mb-2">{calc.name}</h4>
                      <p className="text-sm text-slate-600 mb-3">{calc.description}</p>
                      <div className="text-xs text-blue-600 font-medium">Calculate Now →</div>
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        );
      })}
    </div>
  );
}
