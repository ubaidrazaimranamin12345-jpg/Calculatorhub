import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { UtilityCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function AgeCalculator() {
  const [birthDate, setBirthDate] = useState("");
  const [targetDate, setTargetDate] = useState("");
  const [results, setResults] = useState<any>(null);
  const { toast } = useToast();

  const calculateAge = () => {
    if (!birthDate) {
      toast({
        title: "Invalid Input",
        description: "Please enter your birth date",
        variant: "destructive"
      });
      return;
    }

    const birth = new Date(birthDate);
    const target = targetDate ? new Date(targetDate) : new Date();
    
    if (birth > target) {
      toast({
        title: "Invalid Date",
        description: "Birth date cannot be in the future",
        variant: "destructive"
      });
      return;
    }

    const ageResults = UtilityCalculator.calculateAge(birth);
    
    // Calculate additional time periods
    const birthTime = birth.getTime();
    const targetTime = target.getTime();
    const diffTime = targetTime - birthTime;
    
    const totalWeeks = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7));
    const totalHours = Math.floor(diffTime / (1000 * 60 * 60));
    const totalMinutes = Math.floor(diffTime / (1000 * 60));
    const totalSeconds = Math.floor(diffTime / 1000);

    // Next birthday calculation
    const nextBirthday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday < target) {
      nextBirthday.setFullYear(target.getFullYear() + 1);
    }
    const daysToNextBirthday = Math.ceil((nextBirthday.getTime() - target.getTime()) / (1000 * 60 * 60 * 24));

    setResults({
      ...ageResults,
      totalWeeks,
      totalHours,
      totalMinutes,
      totalSeconds,
      daysToNextBirthday,
      nextBirthday: nextBirthday.toLocaleDateString(),
      calculationDate: target.toLocaleDateString()
    });
  };

  const copyResults = () => {
    if (!results) return;
    
    const resultText = `
Age Calculation Results:
Birth Date: ${new Date(birthDate).toLocaleDateString()}
Calculation Date: ${results.calculationDate}

Current Age: ${results.years} years, ${results.months} months, ${results.days} days

Total Time Lived:
- ${results.totalDays.toLocaleString()} days
- ${results.totalWeeks.toLocaleString()} weeks
- ${results.totalHours.toLocaleString()} hours
- ${results.totalMinutes.toLocaleString()} minutes
- ${results.totalSeconds.toLocaleString()} seconds

Next Birthday: ${results.nextBirthday} (in ${results.daysToNextBirthday} days)
    `.trim();

    navigator.clipboard.writeText(resultText);
    toast({ description: "Results copied to clipboard" });
  };

  // Set today's date as default for target date
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Age Calculator</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="birthDate">Birth Date</Label>
              <Input
                id="birthDate"
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="targetDate">Calculate age as of (optional)</Label>
              <Input
                id="targetDate"
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                placeholder={today}
              />
              <div className="text-xs text-slate-500 mt-1">
                Leave blank to calculate current age
              </div>
            </div>

            <Button onClick={calculateAge} className="w-full">
              Calculate Age
            </Button>
          </CardContent>
        </Card>

        {results && (
          <Card>
            <CardHeader>
              <CardTitle>Your Age</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">
                  {results.years}
                </div>
                <div className="text-lg text-slate-600 mb-4">
                  years, {results.months} months, {results.days} days
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-semibold text-slate-900">
                    {results.totalDays.toLocaleString()}
                  </div>
                  <div className="text-sm text-slate-600">Total Days</div>
                </div>
                
                <div className="bg-slate-50 rounded-lg p-4 text-center">
                  <div className="text-2xl font-semibold text-slate-900">
                    {results.totalWeeks.toLocaleString()}
                  </div>
                  <div className="text-sm text-slate-600">Total Weeks</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Total Hours</span>
                  <span className="font-medium">{results.totalHours.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Total Minutes</span>
                  <span className="font-medium">{results.totalMinutes.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-slate-600">Total Seconds</span>
                  <span className="font-medium">{results.totalSeconds.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-sm font-medium text-blue-900 mb-1">Next Birthday</div>
                <div className="text-blue-700">
                  {results.nextBirthday}
                </div>
                <div className="text-sm text-blue-600">
                  in {results.daysToNextBirthday} days
                </div>
              </div>

              <Button onClick={copyResults} variant="outline" className="w-full">
                <Copy className="h-4 w-4 mr-2" />
                Copy Results
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
