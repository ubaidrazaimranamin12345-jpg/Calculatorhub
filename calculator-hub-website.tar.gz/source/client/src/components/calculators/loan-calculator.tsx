import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FinancialCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function LoanCalculator() {
  const [loanAmount, setLoanAmount] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [loanTerm, setLoanTerm] = useState("");
  const [results, setResults] = useState<any>(null);
  const { toast } = useToast();

  const calculateLoan = () => {
    const amount = parseFloat(loanAmount) || 0;
    const rate = parseFloat(interestRate) || 0;
    const term = parseInt(loanTerm) || 0;

    if (amount <= 0 || rate < 0 || term <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid values for all fields",
        variant: "destructive"
      });
      return;
    }

    const loanResults = FinancialCalculator.calculateLoan(amount, rate, term);
    setResults(loanResults);
  };

  const copyResults = () => {
    if (!results) return;
    
    const resultText = `
Loan Calculation Results:
Loan Amount: $${parseFloat(loanAmount).toLocaleString()}
Interest Rate: ${interestRate}%
Loan Term: ${loanTerm} months

Monthly Payment: $${results.monthlyPayment.toLocaleString()}
Total Interest: $${results.totalInterest.toLocaleString()}
Total Amount Paid: $${results.totalPayment.toLocaleString()}
    `.trim();

    navigator.clipboard.writeText(resultText);
    toast({ description: "Results copied to clipboard" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Loan Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="loanAmount">Loan Amount</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
                <Input
                  id="loanAmount"
                  type="number"
                  placeholder="25,000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="interestRate">Annual Interest Rate</Label>
              <div className="relative">
                <Input
                  id="interestRate"
                  type="number"
                  step="0.01"
                  placeholder="7.5"
                  value={interestRate}
                  onChange={(e) => setInterestRate(e.target.value)}
                  className="pr-8"
                />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
              </div>
            </div>

            <div>
              <Label htmlFor="loanTerm">Loan Term (months)</Label>
              <Input
                id="loanTerm"
                type="number"
                placeholder="60"
                value={loanTerm}
                onChange={(e) => setLoanTerm(e.target.value)}
              />
              <div className="text-xs text-slate-500 mt-1">
                Common terms: 12, 24, 36, 48, 60, 72 months
              </div>
            </div>

            <Button onClick={calculateLoan} className="w-full">
              Calculate Payment
            </Button>
          </CardContent>
        </Card>

        {results && (
          <Card>
            <CardHeader>
              <CardTitle>Loan Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-slate-50 rounded-xl p-6 text-center">
                <h4 className="text-lg font-semibold text-slate-900 mb-2">Monthly Payment</h4>
                <div className="text-3xl font-bold text-blue-600">
                  ${results.monthlyPayment.toLocaleString()}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-slate-200">
                  <span className="text-sm text-slate-600">Loan Amount</span>
                  <span className="font-medium">${parseFloat(loanAmount).toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-slate-200">
                  <span className="text-sm text-slate-600">Interest Rate</span>
                  <span className="font-medium">{interestRate}%</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-slate-200">
                  <span className="text-sm text-slate-600">Loan Term</span>
                  <span className="font-medium">{loanTerm} months</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-slate-200">
                  <span className="text-sm text-slate-600">Total Interest</span>
                  <span className="font-medium text-red-600">${results.totalInterest.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="text-sm font-medium text-slate-900">Total Amount Paid</span>
                  <span className="font-semibold text-lg">${results.totalPayment.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4">
                <div className="text-sm font-medium text-blue-900 mb-1">Interest vs Principal</div>
                <div className="text-xs text-blue-700">
                  Interest: {((results.totalInterest / results.totalPayment) * 100).toFixed(1)}% | 
                  Principal: {((parseFloat(loanAmount) / results.totalPayment) * 100).toFixed(1)}%
                </div>
              </div>

              <Button onClick={copyResults} variant="outline" className="w-full">
                <Copy className="h-4 w-4 mr-2" />
                Copy Results
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
