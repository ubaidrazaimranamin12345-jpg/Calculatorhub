import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FinancialCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function MortgageCalculator() {
  const [homePrice, setHomePrice] = useState("");
  const [downPayment, setDownPayment] = useState("");
  const [downPaymentPercent, setDownPaymentPercent] = useState("");
  const [interestRate, setInterestRate] = useState("");
  const [loanTerm, setLoanTerm] = useState("30");
  const [results, setResults] = useState<any>(null);
  const { toast } = useToast();

  const calculateMortgage = () => {
    const price = parseFloat(homePrice) || 0;
    const down = parseFloat(downPayment) || 0;
    const rate = parseFloat(interestRate) || 0;
    const term = parseInt(loanTerm) || 30;

    if (price <= 0 || rate < 0 || term <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid values for all fields",
        variant: "destructive"
      });
      return;
    }

    const principal = price - down;
    const mortgage = FinancialCalculator.calculateMortgage(principal, rate, term);
    
    // Estimate property tax and insurance (rough estimates)
    const propertyTax = Math.round((price * 0.012) / 12); // 1.2% annually
    const insurance = Math.round((price * 0.0035) / 12); // 0.35% annually
    const totalMonthly = mortgage.monthlyPayment + propertyTax + insurance;

    setResults({
      ...mortgage,
      loanAmount: principal,
      propertyTax,
      insurance,
      totalMonthlyPayment: totalMonthly
    });
  };

  const updateDownPaymentFromPercent = (percent: string) => {
    const price = parseFloat(homePrice) || 0;
    const percentValue = parseFloat(percent) || 0;
    const dollarAmount = (price * percentValue) / 100;
    setDownPayment(dollarAmount.toString());
    setDownPaymentPercent(percent);
  };

  const updateDownPaymentFromDollar = (amount: string) => {
    const price = parseFloat(homePrice) || 0;
    const dollarValue = parseFloat(amount) || 0;
    const percent = price > 0 ? (dollarValue / price) * 100 : 0;
    setDownPaymentPercent(percent.toFixed(1));
    setDownPayment(amount);
  };

  const copyResults = () => {
    if (!results) return;
    
    const resultText = `
Mortgage Calculation Results:
Home Price: $${parseFloat(homePrice).toLocaleString()}
Down Payment: $${parseFloat(downPayment).toLocaleString()}
Loan Amount: $${results.loanAmount.toLocaleString()}
Interest Rate: ${interestRate}%
Loan Term: ${loanTerm} years

Monthly Payment (P&I): $${results.monthlyPayment.toLocaleString()}
Property Tax (est.): $${results.propertyTax}/mo
Insurance (est.): $${results.insurance}/mo
Total Monthly Payment: $${results.totalMonthlyPayment.toLocaleString()}

Total Interest: $${results.totalInterest.toLocaleString()}
Total Paid: $${results.totalPayment.toLocaleString()}
    `.trim();

    navigator.clipboard.writeText(resultText);
    toast({ description: "Results copied to clipboard" });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Mortgage Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="homePrice">Home Price</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
                <Input
                  id="homePrice"
                  type="number"
                  placeholder="400,000"
                  value={homePrice}
                  onChange={(e) => setHomePrice(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>

            <div>
              <Label>Down Payment</Label>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500">$</span>
                  <Input
                    type="number"
                    placeholder="80,000"
                    value={downPayment}
                    onChange={(e) => updateDownPaymentFromDollar(e.target.value)}
                    className="pl-8"
                  />
                </div>
                <div className="relative">
                  <Input
                    type="number"
                    placeholder="20"
                    value={downPaymentPercent}
                    onChange={(e) => updateDownPaymentFromPercent(e.target.value)}
                    className="pr-8"
                  />
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="interestRate">Interest Rate</Label>
              <div className="relative">
                <Input
                  id="interestRate"
                  type="number"
                  step="0.01"
                  placeholder="6.5"
                  value={interestRate}
                  onChange={(e) => setInterestRate(e.target.value)}
                  className="pr-8"
                />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
              </div>
            </div>

            <div>
              <Label>Loan Term</Label>
              <Select value={loanTerm} onValueChange={setLoanTerm}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10 years</SelectItem>
                  <SelectItem value="15">15 years</SelectItem>
                  <SelectItem value="20">20 years</SelectItem>
                  <SelectItem value="30">30 years</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={calculateMortgage} className="w-full">
              Calculate Payment
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
          {results && (
            <>
              <Card>
                <CardContent className="pt-6">
                  <div className="bg-slate-50 rounded-xl p-6">
                    <h4 className="text-lg font-semibold text-slate-900 mb-4">Monthly Payment</h4>
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      ${results.monthlyPayment.toLocaleString()}
                    </div>
                    <div className="text-sm text-slate-600">Principal & Interest</div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm text-slate-600 mb-1">Total Interest</div>
                    <div className="text-xl font-semibold text-slate-900">
                      ${results.totalInterest.toLocaleString()}
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-sm text-slate-600 mb-1">Total Paid</div>
                    <div className="text-xl font-semibold text-slate-900">
                      ${results.totalPayment.toLocaleString()}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-600">Loan Amount</span>
                      <span className="font-medium">${results.loanAmount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-600">Property Tax (est.)</span>
                      <span className="font-medium">${results.propertyTax}/mo</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-600">Insurance (est.)</span>
                      <span className="font-medium">${results.insurance}/mo</span>
                    </div>
                    <div className="pt-2 border-t border-slate-200">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-slate-900">Total Monthly Payment</span>
                        <span className="font-semibold text-lg">${results.totalMonthlyPayment.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button onClick={copyResults} variant="outline" className="w-full">
                <Copy className="h-4 w-4 mr-2" />
                Copy Results
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
