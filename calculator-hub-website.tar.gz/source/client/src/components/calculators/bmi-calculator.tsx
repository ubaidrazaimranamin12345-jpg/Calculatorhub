import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HealthCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function BMICalculator() {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");
  const [unit, setUnit] = useState<"metric" | "imperial">("metric");
  const [results, setResults] = useState<any>(null);
  const { toast } = useToast();

  const calculateBMI = () => {
    const weightValue = parseFloat(weight) || 0;
    const heightValue = parseFloat(height) || 0;

    if (weightValue <= 0 || heightValue <= 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid weight and height values",
        variant: "destructive"
      });
      return;
    }

    const bmiResults = HealthCalculator.calculateBMI(weightValue, heightValue, unit);
    setResults(bmiResults);
  };

  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return "text-blue-600";
    if (bmi < 25) return "text-green-600";
    if (bmi < 30) return "text-yellow-600";
    return "text-red-600";
  };

  const getBMIBarWidth = (bmi: number) => {
    const maxBMI = 40;
    return Math.min((bmi / maxBMI) * 100, 100);
  };

  const copyResults = () => {
    if (!results) return;
    
    const unitLabel = unit === "metric" ? "kg/m²" : "lb/in²";
    const weightUnit = unit === "metric" ? "kg" : "lbs";
    const heightUnit = unit === "metric" ? "cm" : "inches";
    
    const resultText = `
BMI Calculation Results:
Weight: ${weight} ${weightUnit}
Height: ${height} ${heightUnit}

BMI: ${results.bmi} ${unitLabel}
Category: ${results.category}

Healthy Weight Range: ${results.healthyRange.min.toFixed(1)} - ${results.healthyRange.max.toFixed(1)} ${weightUnit}
    `.trim();

    navigator.clipboard.writeText(resultText);
    toast({ description: "Results copied to clipboard" });
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>BMI Calculator</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label>Unit System</Label>
              <Select value={unit} onValueChange={(value: "metric" | "imperial") => setUnit(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="metric">Metric (kg, cm)</SelectItem>
                  <SelectItem value="imperial">Imperial (lbs, inches)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="weight">
                Weight ({unit === "metric" ? "kg" : "lbs"})
              </Label>
              <Input
                id="weight"
                type="number"
                placeholder={unit === "metric" ? "70" : "154"}
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="height">
                Height ({unit === "metric" ? "cm" : "inches"})
              </Label>
              <Input
                id="height"
                type="number"
                placeholder={unit === "metric" ? "175" : "69"}
                value={height}
                onChange={(e) => setHeight(e.target.value)}
              />
            </div>

            <Button onClick={calculateBMI} className="w-full">
              Calculate BMI
            </Button>
          </CardContent>
        </Card>

        {results && (
          <Card>
            <CardHeader>
              <CardTitle>Your BMI Results</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className={`text-4xl font-bold mb-2 ${getBMIColor(results.bmi)}`}>
                  {results.bmi}
                </div>
                <div className="text-sm text-slate-600">BMI</div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Underweight</span>
                  <span>Normal</span>
                  <span>Overweight</span>
                  <span>Obese</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3 relative">
                  <div className="absolute h-3 rounded-full bg-gradient-to-r from-blue-400 via-green-400 via-yellow-400 to-red-400 w-full"></div>
                  <div 
                    className="absolute h-3 w-1 bg-black rounded-full"
                    style={{ left: `${getBMIBarWidth(results.bmi)}%` }}
                  ></div>
                </div>
                <div className="text-xs text-slate-500 flex justify-between">
                  <span>18.5</span>
                  <span>25</span>
                  <span>30</span>
                  <span>35+</span>
                </div>
              </div>

              <div className="bg-slate-50 rounded-lg p-4">
                <div className="text-sm font-medium text-slate-900 mb-2">Category</div>
                <div className={`text-lg font-semibold ${getBMIColor(results.bmi)}`}>
                  {results.category}
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-slate-900">Healthy Weight Range</div>
                <div className="text-sm text-slate-600">
                  {results.healthyRange.min.toFixed(1)} - {results.healthyRange.max.toFixed(1)} {unit === "metric" ? "kg" : "lbs"}
                </div>
              </div>

              <Button onClick={copyResults} variant="outline" className="w-full">
                <Copy className="h-4 w-4 mr-2" />
                Copy Results
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
