import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MathCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function PercentageCalculator() {
  const [value1, setValue1] = useState("");
  const [value2, setValue2] = useState("");
  const [value3, setValue3] = useState("");
  const [results, setResults] = useState<any>({});
  const { toast } = useToast();

  const calculateBasicPercentage = () => {
    const num = parseFloat(value1) || 0;
    const percent = parseFloat(value2) || 0;
    
    if (num === 0 && percent === 0) {
      toast({
        title: "Invalid Input",
        description: "Please enter valid values",
        variant: "destructive"
      });
      return;
    }
    
    const result = MathCalculator.calculatePercentage(num, percent);
    setResults({ ...results, basic: result });
  };

  const calculatePercentageOf = () => {
    const part = parseFloat(value1) || 0;
    const whole = parseFloat(value2) || 0;
    
    if (whole === 0) {
      toast({
        title: "Invalid Input",
        description: "Cannot divide by zero",
        variant: "destructive"
      });
      return;
    }
    
    const result = (part / whole) * 100;
    setResults({ ...results, percentageOf: result });
  };

  const calculatePercentageChange = () => {
    const oldValue = parseFloat(value1) || 0;
    const newValue = parseFloat(value2) || 0;
    
    if (oldValue === 0) {
      toast({
        title: "Invalid Input",
        description: "Original value cannot be zero",
        variant: "destructive"
      });
      return;
    }
    
    const result = MathCalculator.calculatePercentageChange(oldValue, newValue);
    const isIncrease = result > 0;
    setResults({ 
      ...results, 
      percentageChange: {
        value: Math.abs(result),
        isIncrease,
        difference: Math.abs(newValue - oldValue)
      }
    });
  };

  const calculatePercentageIncrease = () => {
    const originalValue = parseFloat(value1) || 0;
    const percentIncrease = parseFloat(value2) || 0;
    
    const newValue = originalValue + MathCalculator.calculatePercentage(originalValue, percentIncrease);
    const increase = newValue - originalValue;
    
    setResults({ 
      ...results, 
      percentageIncrease: {
        newValue,
        increase
      }
    });
  };

  const calculatePercentageDecrease = () => {
    const originalValue = parseFloat(value1) || 0;
    const percentDecrease = parseFloat(value2) || 0;
    
    const newValue = originalValue - MathCalculator.calculatePercentage(originalValue, percentDecrease);
    const decrease = originalValue - newValue;
    
    setResults({ 
      ...results, 
      percentageDecrease: {
        newValue,
        decrease
      }
    });
  };

  const copyResults = (resultKey: string) => {
    const result = results[resultKey];
    if (result === undefined) return;
    
    let resultText = "";
    switch (resultKey) {
      case "basic":
        resultText = `${value2}% of ${value1} = ${result}`;
        break;
      case "percentageOf":
        resultText = `${value1} is ${result.toFixed(2)}% of ${value2}`;
        break;
      case "percentageChange":
        resultText = `Change from ${value1} to ${value2}: ${result.isIncrease ? '+' : '-'}${result.value.toFixed(2)}% (${result.isIncrease ? 'increase' : 'decrease'} of ${result.difference})`;
        break;
      case "percentageIncrease":
        resultText = `${value1} increased by ${value2}%: ${result.newValue.toFixed(2)} (increase of ${result.increase.toFixed(2)})`;
        break;
      case "percentageDecrease":
        resultText = `${value1} decreased by ${value2}%: ${result.newValue.toFixed(2)} (decrease of ${result.decrease.toFixed(2)})`;
        break;
    }
    
    navigator.clipboard.writeText(resultText);
    toast({ description: "Result copied to clipboard" });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">Basic %</TabsTrigger>
          <TabsTrigger value="what-percent">What %</TabsTrigger>
          <TabsTrigger value="change">% Change</TabsTrigger>
          <TabsTrigger value="increase">Increase</TabsTrigger>
          <TabsTrigger value="decrease">Decrease</TabsTrigger>
        </TabsList>

        <TabsContent value="basic">
          <Card>
            <CardHeader>
              <CardTitle>What is X% of Y?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="percent">Percentage</Label>
                  <div className="relative">
                    <Input
                      id="percent"
                      type="number"
                      placeholder="25"
                      value={value2}
                      onChange={(e) => setValue2(e.target.value)}
                      className="pr-8"
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
                  </div>
                </div>
                <div>
                  <Label htmlFor="number">of</Label>
                  <Input
                    id="number"
                    type="number"
                    placeholder="100"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <Button onClick={calculateBasicPercentage}>Calculate</Button>
              </div>
              
              {results.basic !== undefined && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600 mb-2">
                        {results.basic.toLocaleString()}
                      </div>
                      <div className="text-sm text-slate-600 mb-4">
                        {value2}% of {value1} = {results.basic}
                      </div>
                      <Button onClick={() => copyResults("basic")} variant="outline" size="sm">
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Result
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="what-percent">
          <Card>
            <CardHeader>
              <CardTitle>X is what percent of Y?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="part">Part</Label>
                  <Input
                    id="part"
                    type="number"
                    placeholder="25"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="whole">is what % of</Label>
                  <Input
                    id="whole"
                    type="number"
                    placeholder="100"
                    value={value2}
                    onChange={(e) => setValue2(e.target.value)}
                  />
                </div>
                <Button onClick={calculatePercentageOf}>Calculate</Button>
              </div>
              
              {results.percentageOf !== undefined && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600 mb-2">
                        {results.percentageOf.toFixed(2)}%
                      </div>
                      <div className="text-sm text-slate-600 mb-4">
                        {value1} is {results.percentageOf.toFixed(2)}% of {value2}
                      </div>
                      <Button onClick={() => copyResults("percentageOf")} variant="outline" size="sm">
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Result
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="change">
          <Card>
            <CardHeader>
              <CardTitle>Percentage Change</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="oldValue">Original Value</Label>
                  <Input
                    id="oldValue"
                    type="number"
                    placeholder="100"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="newValue">New Value</Label>
                  <Input
                    id="newValue"
                    type="number"
                    placeholder="120"
                    value={value2}
                    onChange={(e) => setValue2(e.target.value)}
                  />
                </div>
                <Button onClick={calculatePercentageChange}>Calculate</Button>
              </div>
              
              {results.percentageChange && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className={`text-3xl font-bold mb-2 ${results.percentageChange.isIncrease ? 'text-green-600' : 'text-red-600'}`}>
                        {results.percentageChange.isIncrease ? '+' : '-'}{results.percentageChange.value.toFixed(2)}%
                      </div>
                      <div className="text-sm text-slate-600 mb-2">
                        {results.percentageChange.isIncrease ? 'Increase' : 'Decrease'} of {results.percentageChange.difference.toFixed(2)}
                      </div>
                      <div className="text-sm text-slate-600 mb-4">
                        From {value1} to {value2}
                      </div>
                      <Button onClick={() => copyResults("percentageChange")} variant="outline" size="sm">
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Result
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="increase">
          <Card>
            <CardHeader>
              <CardTitle>Percentage Increase</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="originalIncrease">Original Value</Label>
                  <Input
                    id="originalIncrease"
                    type="number"
                    placeholder="100"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="increasePercent">Increase by</Label>
                  <div className="relative">
                    <Input
                      id="increasePercent"
                      type="number"
                      placeholder="20"
                      value={value2}
                      onChange={(e) => setValue2(e.target.value)}
                      className="pr-8"
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
                  </div>
                </div>
                <Button onClick={calculatePercentageIncrease}>Calculate</Button>
              </div>
              
              {results.percentageIncrease && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600 mb-2">
                        {results.percentageIncrease.newValue.toFixed(2)}
                      </div>
                      <div className="text-sm text-slate-600 mb-2">
                        New value after {value2}% increase
                      </div>
                      <div className="text-sm text-slate-600 mb-4">
                        Increase of {results.percentageIncrease.increase.toFixed(2)}
                      </div>
                      <Button onClick={() => copyResults("percentageIncrease")} variant="outline" size="sm">
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Result
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="decrease">
          <Card>
            <CardHeader>
              <CardTitle>Percentage Decrease</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                <div>
                  <Label htmlFor="originalDecrease">Original Value</Label>
                  <Input
                    id="originalDecrease"
                    type="number"
                    placeholder="100"
                    value={value1}
                    onChange={(e) => setValue1(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="decreasePercent">Decrease by</Label>
                  <div className="relative">
                    <Input
                      id="decreasePercent"
                      type="number"
                      placeholder="20"
                      value={value2}
                      onChange={(e) => setValue2(e.target.value)}
                      className="pr-8"
                    />
                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-500">%</span>
                  </div>
                </div>
                <Button onClick={calculatePercentageDecrease}>Calculate</Button>
              </div>
              
              {results.percentageDecrease && (
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-600 mb-2">
                        {results.percentageDecrease.newValue.toFixed(2)}
                      </div>
                      <div className="text-sm text-slate-600 mb-2">
                        New value after {value2}% decrease
                      </div>
                      <div className="text-sm text-slate-600 mb-4">
                        Decrease of {results.percentageDecrease.decrease.toFixed(2)}
                      </div>
                      <Button onClick={() => copyResults("percentageDecrease")} variant="outline" size="sm">
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Result
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
