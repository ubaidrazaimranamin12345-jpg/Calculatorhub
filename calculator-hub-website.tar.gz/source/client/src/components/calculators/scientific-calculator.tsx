import { useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScientificCalculator } from "@/lib/calculator-utils";
import { useToast } from "@/hooks/use-toast";

export default function ScientificCalculatorComponent() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [memory, setMemory] = useState(0);
  const [isDegMode, setIsDegMode] = useState(true);
  const { toast } = useToast();

  const handleNumber = (num: string) => {
    if (display === "0" || display === "Error") {
      setDisplay(num);
      setExpression(num);
    } else {
      setDisplay(display + num);
      setExpression(expression + num);
    }
  };

  const handleOperator = (op: string) => {
    const operators: { [key: string]: string } = {
      "÷": "/",
      "×": "*",
      "−": "-",
      "+": "+"
    };
    
    const mathOp = operators[op] || op;
    setExpression(expression + mathOp);
    setDisplay(display + op);
  };

  const handleFunction = (func: string) => {
    let funcStr = "";
    switch (func) {
      case "sin":
      case "cos":
      case "tan":
        funcStr = `${func}(`;
        break;
      case "sin⁻¹":
        funcStr = "asin(";
        break;
      case "cos⁻¹":
        funcStr = "acos(";
        break;
      case "tan⁻¹":
        funcStr = "atan(";
        break;
      case "ln":
        funcStr = "ln(";
        break;
      case "log":
        funcStr = "log(";
        break;
      case "√x":
        funcStr = "sqrt(";
        break;
      case "x²":
        setExpression(expression + "^2");
        setDisplay(display + "²");
        return;
      case "x³":
        setExpression(expression + "^3");
        setDisplay(display + "³");
        return;
      case "xʸ":
        setExpression(expression + "^");
        setDisplay(display + "^");
        return;
      default:
        return;
    }
    
    setExpression(expression + funcStr);
    setDisplay(display + func + "(");
  };

  const handleConstant = (constant: string) => {
    const value = constant === "π" ? "π" : "e";
    setExpression(expression + value);
    setDisplay(display + constant);
  };

  const handleEquals = () => {
    try {
      let expr = expression;
      
      // Convert trigonometric functions to radians if in degree mode
      if (isDegMode) {
        expr = expr.replace(/sin\(([^)]+)\)/g, (match, angle) => `sin(${angle}*π/180)`);
        expr = expr.replace(/cos\(([^)]+)\)/g, (match, angle) => `cos(${angle}*π/180)`);
        expr = expr.replace(/tan\(([^)]+)\)/g, (match, angle) => `tan(${angle}*π/180)`);
      }
      
      const result = ScientificCalculator.evaluate(expr);
      setDisplay(result.toString());
      setExpression(result.toString());
    } catch (error) {
      setDisplay("Error");
      setExpression("");
    }
  };

  const handleClear = () => {
    setDisplay("0");
    setExpression("");
  };

  const handleBackspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
      setExpression(expression.slice(0, -1));
    } else {
      setDisplay("0");
      setExpression("");
    }
  };

  const handleMemoryStore = () => {
    setMemory(parseFloat(display) || 0);
    toast({ description: "Value stored in memory" });
  };

  const handleMemoryRecall = () => {
    setDisplay(memory.toString());
    setExpression(memory.toString());
  };

  const handleMemoryClear = () => {
    setMemory(0);
    toast({ description: "Memory cleared" });
  };

  const copyResult = () => {
    navigator.clipboard.writeText(display);
    toast({ description: "Result copied to clipboard" });
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 max-w-2xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Display */}
        <div className="lg:col-span-5 mb-4">
          <div className="bg-slate-900 rounded-lg p-4 text-right">
            <div className="text-slate-400 text-sm font-mono mb-1 min-h-[1.25rem]">
              {expression || " "}
            </div>
            <div className="text-white text-2xl font-mono break-all">
              {display}
            </div>
          </div>
        </div>

        {/* Scientific Functions */}
        <div className="lg:col-span-2 grid grid-cols-4 gap-2">
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("sin")}
          >
            sin
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("cos")}
          >
            cos
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("tan")}
          >
            tan
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => setIsDegMode(!isDegMode)}
          >
            {isDegMode ? "Deg" : "Rad"}
          </Button>
          
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("sin⁻¹")}
          >
            sin⁻¹
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("cos⁻¹")}
          >
            cos⁻¹
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("tan⁻¹")}
          >
            tan⁻¹
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleConstant("π")}
          >
            π
          </Button>
          
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("x²")}
          >
            x²
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("x³")}
          >
            x³
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("xʸ")}
          >
            xʸ
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleConstant("e")}
          >
            e
          </Button>
          
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("√x")}
          >
            √x
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("³√x")}
          >
            ³√x
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("ln")}
          >
            ln
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 px-2 text-sm"
            onClick={() => handleFunction("log")}
          >
            log
          </Button>
        </div>

        {/* Basic Calculator */}
        <div className="lg:col-span-3 grid grid-cols-4 gap-2">
          <Button
            variant="destructive"
            className="calc-button py-3"
            onClick={handleClear}
          >
            AC
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 bg-orange-100 hover:bg-orange-200 text-orange-700"
            onClick={handleBackspace}
          >
            ⌫
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3"
            onClick={() => {
              setExpression(expression + "(");
              setDisplay(display + "(");
            }}
          >
            ( )
          </Button>
          <Button
            variant="secondary"
            className="calc-button py-3 bg-blue-100 hover:bg-blue-200 text-blue-700"
            onClick={() => handleOperator("÷")}
          >
            ÷
          </Button>
          
          {["7", "8", "9"].map(num => (
            <Button
              key={num}
              variant="outline"
              className="calc-button py-3"
              onClick={() => handleNumber(num)}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="calc-button py-3 bg-blue-100 hover:bg-blue-200 text-blue-700"
            onClick={() => handleOperator("×")}
          >
            ×
          </Button>
          
          {["4", "5", "6"].map(num => (
            <Button
              key={num}
              variant="outline"
              className="calc-button py-3"
              onClick={() => handleNumber(num)}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="calc-button py-3 bg-blue-100 hover:bg-blue-200 text-blue-700"
            onClick={() => handleOperator("−")}
          >
            −
          </Button>
          
          {["1", "2", "3"].map(num => (
            <Button
              key={num}
              variant="outline"
              className="calc-button py-3"
              onClick={() => handleNumber(num)}
            >
              {num}
            </Button>
          ))}
          <Button
            variant="secondary"
            className="calc-button py-3 bg-blue-100 hover:bg-blue-200 text-blue-700"
            onClick={() => handleOperator("+")}
          >
            +
          </Button>
          
          <Button
            variant="outline"
            className="calc-button py-3 col-span-2"
            onClick={() => handleNumber("0")}
          >
            0
          </Button>
          <Button
            variant="outline"
            className="calc-button py-3"
            onClick={() => {
              if (!display.includes(".")) {
                handleNumber(".");
              }
            }}
          >
            .
          </Button>
          <Button
            className="calc-button py-3 bg-emerald-500 hover:bg-emerald-600"
            onClick={handleEquals}
          >
            =
          </Button>
        </div>
      </div>
      
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200">
        <div className="flex items-center space-x-4 text-sm text-slate-600">
          <span>Memory: <span className="font-mono">{memory}</span></span>
          <Button variant="ghost" size="sm" onClick={handleMemoryStore}>
            MS
          </Button>
          <Button variant="ghost" size="sm" onClick={handleMemoryRecall}>
            MR
          </Button>
          <Button variant="ghost" size="sm" onClick={handleMemoryClear}>
            MC
          </Button>
        </div>
        <Button variant="ghost" size="sm" onClick={copyResult}>
          <Copy className="h-4 w-4 mr-2" />
          Copy Result
        </Button>
      </div>
    </div>
  );
}
