#!/bin/bash

echo "Building Calculator Hub for production deployment..."

# Install dependencies
echo "Installing dependencies..."
npm install

# Build client (frontend)
echo "Building client..."
npx vite build --outDir dist

# Build server (backend)
echo "Building server..."
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist-server

echo "Build complete!"
echo "Frontend built in: ./dist/"
echo "Backend built in: ./dist-server/"

echo ""
echo "To deploy:"
echo "1. For static hosting: Upload contents of 'dist' folder"
echo "2. For full-stack hosting: Deploy both 'dist' and 'dist-server' folders"
echo "3. Set NODE_ENV=production and run: node dist-server/index.js"