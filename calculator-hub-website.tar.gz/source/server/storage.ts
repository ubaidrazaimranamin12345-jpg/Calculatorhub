import { type CalculatorHistory, type InsertCalculatorHistory } from "@shared/schema";
import { randomUUID } from "crypto";

// Storage interface for calculator operations
export interface IStorage {
  getCalculatorHistory(id: string): Promise<CalculatorHistory | undefined>;
  createCalculatorHistory(history: InsertCalculatorHistory): Promise<CalculatorHistory>;
  getAllCalculatorHistory(): Promise<CalculatorHistory[]>;
}

export class MemStorage implements IStorage {
  private calculatorHistory: Map<string, CalculatorHistory>;

  constructor() {
    this.calculatorHistory = new Map();
  }

  async getCalculatorHistory(id: string): Promise<CalculatorHistory | undefined> {
    return this.calculatorHistory.get(id);
  }

  async createCalculatorHistory(insertHistory: InsertCalculatorHistory): Promise<CalculatorHistory> {
    const id = randomUUID();
    const history: CalculatorHistory = { 
      ...insertHistory, 
      id,
      createdAt: new Date()
    };
    this.calculatorHistory.set(id, history);
    return history;
  }

  async getAllCalculatorHistory(): Promise<CalculatorHistory[]> {
    return Array.from(this.calculatorHistory.values());
  }
}

export const storage = new MemStorage();
