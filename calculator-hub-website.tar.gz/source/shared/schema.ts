import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const calculatorHistory = pgTable("calculator_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  calculatorType: text("calculator_type").notNull(),
  inputs: jsonb("inputs").notNull(),
  results: jsonb("results").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCalculatorHistorySchema = createInsertSchema(calculatorHistory).pick({
  calculatorType: true,
  inputs: true,
  results: true,
});

export type InsertCalculatorHistory = z.infer<typeof insertCalculatorHistorySchema>;
export type CalculatorHistory = typeof calculatorHistory.$inferSelect;
